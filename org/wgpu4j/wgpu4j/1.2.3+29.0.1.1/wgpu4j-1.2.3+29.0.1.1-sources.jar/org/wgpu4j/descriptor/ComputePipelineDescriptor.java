package org.wgpu4j.descriptor;

import org.wgpu4j.Marshalable;
import org.wgpu4j.bindings.WGPUComputePipelineDescriptor;
import org.wgpu4j.bindings.WGPUComputeState;
import org.wgpu4j.bindings.WGPUConstantEntry;
import org.wgpu4j.bindings.WGPUStringView;
import org.wgpu4j.resource.PipelineLayout;
import org.wgpu4j.resource.ShaderModule;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Configuration for creating a compute pipeline.
 * Compute pipelines execute compute shaders for general-purpose GPU computing.
 */
public class ComputePipelineDescriptor implements Marshalable {
    private final String label;
    private final PipelineLayout pipelineLayout;
    private final ShaderModule computeShader;
    private final String entryPoint;
    private final List<ConstantEntry> constants = new ArrayList<>();

    private ComputePipelineDescriptor(Builder builder) {
        this.label = builder.label;
        this.pipelineLayout = builder.pipelineLayout;
        this.computeShader = builder.computeShader;
        this.entryPoint = builder.entryPoint;
        this.constants.addAll(builder.constants);
    }

    public String getLabel() {
        return label;
    }

    public List<ConstantEntry> getConstants() {
        return constants;
    }

    public PipelineLayout getPipelineLayout() {
        return pipelineLayout;
    }

    public ShaderModule getComputeShader() {
        return computeShader;
    }

    public String getEntryPoint() {
        return entryPoint;
    }

    /**
     * Converts this descriptor to a C struct using jextract layouts.
     *
     * @param arena The arena to allocate the struct in
     * @return MemorySegment representing the WGPUComputePipelineDescriptor struct
     */
    public MemorySegment marshal(Arena arena) {
        MemorySegment descriptor = WGPUComputePipelineDescriptor.allocate(arena);

        WGPUComputePipelineDescriptor.nextInChain(descriptor, MemorySegment.NULL);

        MemorySegment labelView = WGPUStringView.allocate(arena);
        if (label != null && !label.isEmpty()) {
            MemorySegment labelData = arena.allocateFrom(label);
            WGPUStringView.data(labelView, labelData);
            WGPUStringView.length(labelView, label.length());
        } else {
            WGPUStringView.data(labelView, MemorySegment.NULL);
            WGPUStringView.length(labelView, 0);
        }
        MemorySegment.copy(labelView, 0, descriptor, WGPUComputePipelineDescriptor.label$offset(), WGPUStringView.sizeof());

        if (pipelineLayout != null) {
            WGPUComputePipelineDescriptor.layout(descriptor, pipelineLayout.getHandle());
        } else {
            WGPUComputePipelineDescriptor.layout(descriptor, MemorySegment.NULL);
        }

        MemorySegment computeStage = WGPUComputePipelineDescriptor.compute(descriptor);
        setupComputeStage(computeStage, arena);

        return descriptor;
    }

    private void setupComputeStage(MemorySegment computeStage, Arena arena) {
        WGPUComputeState.nextInChain(computeStage, MemorySegment.NULL);

        WGPUComputeState.module(computeStage, computeShader.getHandle());

        MemorySegment entryPointView = WGPUComputeState.entryPoint(computeStage);
        MemorySegment entryPointData = arena.allocateFrom(entryPoint, StandardCharsets.UTF_8);
        WGPUStringView.data(entryPointView, entryPointData);
        WGPUStringView.length(entryPointView, entryPoint.length());

        WGPUComputeState.constantCount(computeStage, constants.size());
        if (!constants.isEmpty()) {
            MemorySegment constantsArray = WGPUConstantEntry.allocateArray(constants.size(), arena);
            for (int i = 0; i < constants.size(); i++) {
                MemorySegment constantStruct = WGPUConstantEntry.asSlice(constantsArray, i);
                constants.get(i).marshal(arena, constantStruct);
            }
            WGPUComputeState.constants(computeStage, constantsArray);
        } else {
            WGPUComputeState.constants(computeStage, MemorySegment.NULL);
        }
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String label = "";
        private PipelineLayout pipelineLayout;
        private ShaderModule computeShader;
        private String entryPoint = "main";
        private List<ConstantEntry> constants = new ArrayList<>();

        /**
         * Adds a constant to the compute shader.
         *
         * @param name The constant name
         * @param value The constant value
         * @return this builder
         */
        public Builder constant(String name, double value) {
            this.constants.add(new ConstantEntry(name, value));
            return this;
        }

        /**
         * Adds constants to the compute shader.
         *
         * @param entries The constant entry list
         * @return this builder
         */
        public Builder constant(ConstantEntry... entries) {
            this.constants.addAll(List.of(entries));
            return this;
        }

        /**
         * Adds constants to the compute shader.
         *
         * @param entries The constant entry list
         * @return this builder
         */
        public Builder constant(List<ConstantEntry> entries) {
            this.constants.addAll(entries);
            return this;
        }

        /**
         * Sets the debug label for the compute pipeline.
         *
         * @param label The debug label
         * @return this builder
         */
        public Builder label(String label) {
            this.label = label;
            return this;
        }

        /**
         * Sets the pipeline layout defining resource binding groups.
         * If not set, auto-layout will be used.
         *
         * @param pipelineLayout The pipeline layout
         * @return this builder
         */
        public Builder pipelineLayout(PipelineLayout pipelineLayout) {
            this.pipelineLayout = pipelineLayout;
            return this;
        }

        /**
         * Sets the compute shader module.
         *
         * @param computeShader The compute shader module
         * @return this builder
         */
        public Builder computeShader(ShaderModule computeShader) {
            this.computeShader = computeShader;
            return this;
        }

        /**
         * Sets the entry point function name in the compute shader.
         * Default is "main".
         *
         * @param entryPoint The entry point function name
         * @return this builder
         */
        public Builder entryPoint(String entryPoint) {
            this.entryPoint = entryPoint;
            return this;
        }

        public ComputePipelineDescriptor build() {
            if (computeShader == null) {
                throw new IllegalArgumentException("Compute shader is required");
            }
            if (entryPoint == null || entryPoint.isEmpty()) {
                throw new IllegalArgumentException("Entry point is required");
            }
            return new ComputePipelineDescriptor(this);
        }
    }
}