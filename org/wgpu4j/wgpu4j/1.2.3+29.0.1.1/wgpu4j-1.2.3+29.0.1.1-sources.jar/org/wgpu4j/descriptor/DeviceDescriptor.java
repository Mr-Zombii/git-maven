package org.wgpu4j.descriptor;

import org.wgpu4j.Marshalable;
import org.wgpu4j.bindings.*;
import org.wgpu4j.constant.DeviceLostReason;
import org.wgpu4j.constant.FeatureName;
import org.wgpu4j.constant.RequestDeviceStatus;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Configuration for creating a GPU device.
 */
public class DeviceDescriptor implements Marshalable {
    private final String label;
    private final List<FeatureName> requiredFeatures;
    private final QueueDescriptor defaultQueue;
    private final Limits requiredLimits;
    private final DeviceLostCallback lostCallback;
    private final UncapturedErrorCallback uncapturedErrorCallback;

    private DeviceDescriptor(
            String label, List<FeatureName> requiredFeatures, QueueDescriptor defaultQueue,
            Limits requiredLimits, DeviceLostCallback lostCallback, UncapturedErrorCallback uncapturedErrorCallback
    ) {
        this.label = label;
        this.requiredFeatures = new ArrayList<>(requiredFeatures);
        this.defaultQueue = defaultQueue;
        this.requiredLimits = requiredLimits;
        this.lostCallback = lostCallback;
        this.uncapturedErrorCallback = uncapturedErrorCallback;
    }

    public DeviceLostCallback getLostCallback() {
        return lostCallback;
    }

    public UncapturedErrorCallback getUncapturedErrorCallback() {
        return uncapturedErrorCallback;
    }

    public String getLabel() {
        return label;
    }

    public List<FeatureName> getRequiredFeatures() {
        return new ArrayList<>(requiredFeatures);
    }

    public QueueDescriptor getDefaultQueue() {
        return defaultQueue;
    }

    public Limits getRequiredLimits() {
        return requiredLimits;
    }

    /**
     * Converts this descriptor to a C struct using jextract layouts.
     *
     * @param arena The arena to allocate the struct in
     * @return MemorySegment representing the WGPUDeviceDescriptor struct
     */
    public MemorySegment marshal(Arena arena) {
        MemorySegment struct = WGPUDeviceDescriptor.allocate(arena);

        WGPUDeviceDescriptor.nextInChain(struct, MemorySegment.NULL);

        if (label != null && !label.isEmpty()) {
            MemorySegment labelBytes = arena.allocateFrom(label, StandardCharsets.UTF_8);
            MemorySegment labelStringView = WGPUDeviceDescriptor.label(struct);
            WGPUStringView.data(labelStringView, labelBytes);
            WGPUStringView.length(labelStringView, label.length());
        } else {
            MemorySegment labelStringView = WGPUDeviceDescriptor.label(struct);
            WGPUStringView.data(labelStringView, MemorySegment.NULL);
            WGPUStringView.length(labelStringView, 0);
        }

        WGPUDeviceDescriptor.requiredFeatureCount(struct, requiredFeatures.size());
        if (!requiredFeatures.isEmpty()) {
            MemorySegment featuresArray = arena.allocate(ValueLayout.JAVA_INT, requiredFeatures.size());
            for (int i = 0; i < requiredFeatures.size(); i++) {
                featuresArray.setAtIndex(ValueLayout.JAVA_INT, i, requiredFeatures.get(i).getValue());
            }
            WGPUDeviceDescriptor.requiredFeatures(struct, featuresArray);
        } else {
            WGPUDeviceDescriptor.requiredFeatures(struct, MemorySegment.NULL);
        }

        if (requiredLimits != null) {
            MemorySegment limitsStruct = requiredLimits.marshal(arena);
            WGPUDeviceDescriptor.requiredLimits(struct, limitsStruct);
        } else {
            WGPUDeviceDescriptor.requiredLimits(struct, MemorySegment.NULL);
        }

        MemorySegment deviceLostCallbackInfo = WGPUDeviceDescriptor.deviceLostCallbackInfo(struct);
        deviceLostCallbackInfo.fill((byte) 0);
        if (lostCallback != null) {
            WGPUDeviceLostCallbackInfo.mode(deviceLostCallbackInfo, webgpu_h.WGPUCallbackMode_AllowProcessEvents());

            WGPUDeviceLostCallback.Function function = new WGPUDeviceLostCallback.Function() {
                @Override
                public void apply(
                        MemorySegment device, int reason,
                        MemorySegment message, MemorySegment userdata1,
                        MemorySegment userdata2
                ) {
                    String strMessage = extractStringView(message);
                    lostCallback.onLost(DeviceLostReason.fromValue(reason), strMessage);
                }
            };

            MemorySegment callback = WGPUDeviceLostCallback.allocate(function, arena);
            WGPUDeviceLostCallbackInfo.callback(deviceLostCallbackInfo, callback);
        }

        MemorySegment uncapturedErrorCallbackInfo = WGPUDeviceDescriptor.uncapturedErrorCallbackInfo(struct);
        uncapturedErrorCallbackInfo.fill((byte) 0);

        if (uncapturedErrorCallback != null) {
            WGPUUncapturedErrorCallback.Function function = new WGPUUncapturedErrorCallback.Function() {
                @Override
                public void apply(
                        MemorySegment device, int type,
                        MemorySegment message, MemorySegment userdata1,
                        MemorySegment userdata2
                ) {
                    String strMessage = extractStringView(message);
                    uncapturedErrorCallback.onError(RequestDeviceStatus.fromValue(type), strMessage);
                }
            };

            MemorySegment callback = WGPUUncapturedErrorCallback.allocate(function, arena);
            WGPUUncapturedErrorCallbackInfo.callback(uncapturedErrorCallbackInfo, callback);
        }

        MemorySegment queueStruct = defaultQueue.marshal(arena);
        MemorySegment defaultQueueField = WGPUDeviceDescriptor.defaultQueue(struct);
        MemorySegment.copy(queueStruct, 0L, defaultQueueField, 0L, WGPUQueueDescriptor.sizeof());

        return struct;
    }

    /**
     * Extracts a Java string from a WGPUStringView.
     */
    private String extractStringView(MemorySegment stringView) {
        try {
            if (stringView.equals(MemorySegment.NULL)) {
                return "";
            }

            MemorySegment dataPtr = WGPUStringView.data(stringView);
            long length = WGPUStringView.length(stringView);

            if (dataPtr.equals(MemorySegment.NULL) || length <= 0) {
                return "";
            }

            // Check if the data pointer can be safely read
            MemorySegment validatedPtr = dataPtr.reinterpret(length);
            return validatedPtr.getString(0, java.nio.charset.StandardCharsets.UTF_8);

        } catch (Exception e) {
            return "Error reading message: " + e.getMessage();
        }
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private String label = "";
        private List<FeatureName> requiredFeatures = new ArrayList<>();
        private QueueDescriptor defaultQueue = QueueDescriptor.builder().build();
        private Limits requiredLimits = null;
        private DeviceLostCallback lostCallback = (reason, message) -> {};
        private UncapturedErrorCallback uncapturedErrorCallback = (reason, message) -> {};

        public Builder label(String label) {
            this.label = label;
            return this;
        }

        public Builder lostCallback(DeviceLostCallback lostCallback) {
            this.lostCallback = lostCallback;
            return this;
        }

        public Builder errorCallback(UncapturedErrorCallback errorCallback) {
            this.uncapturedErrorCallback = errorCallback;
            return this;
        }

        public Builder requiredFeature(FeatureName feature) {
            this.requiredFeatures.add(feature);
            return this;
        }

        public Builder requiredFeatures(List<FeatureName> features) {
            this.requiredFeatures.clear();
            this.requiredFeatures.addAll(features);
            return this;
        }

        public Builder defaultQueue(QueueDescriptor queue) {
            this.defaultQueue = queue;
            return this;
        }

        public Builder requiredLimits(Limits limits) {
            this.requiredLimits = limits;
            return this;
        }

        public DeviceDescriptor build() {
            return new DeviceDescriptor(label, requiredFeatures, defaultQueue, requiredLimits, lostCallback, uncapturedErrorCallback);
        }
    }

    // https://doc.qu1x.dev/bevy_trackball/wgpu/struct.Device.html#method.set_device_lost_callback
    public interface DeviceLostCallback {

        void onLost(DeviceLostReason reason, String message);

    }

    public interface UncapturedErrorCallback {

        void onError(RequestDeviceStatus requestDeviceStatus, String strMessage);

    }

}